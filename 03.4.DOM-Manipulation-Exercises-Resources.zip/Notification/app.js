function notify(message) {
    // TODO:
}