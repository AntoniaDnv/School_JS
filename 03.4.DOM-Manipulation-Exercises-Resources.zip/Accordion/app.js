function toggle() {
    // TODO
}