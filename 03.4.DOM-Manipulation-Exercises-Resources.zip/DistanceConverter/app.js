function attachEventsListeners() {
    // TODO: attach click event to convert button
}