function subtract() {
    // TODO
}