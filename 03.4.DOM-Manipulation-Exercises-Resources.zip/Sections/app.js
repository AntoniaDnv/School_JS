function create(sentences) {
    // TODO:
}