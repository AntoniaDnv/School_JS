function attachEventsListeners() {
    // TODO
}