function addItem() {
    // TODO
}